import scrapy


class rentalSpider(scrapy.Spider):
    name = "rental"

    start_urls = [
        'file:///Users/mac/data_visualization_web/portland_maine/tutorial/tutorial/spiders/Rental%20Listings%20-%2063%20Rentals%20%7C%20Zillow.html',
    ]

    def parse(self, response):
        for apts in response.css('div.list-card-info'):

            yield{
                'location': apts.css('address.list-card-addr::text').get(),
                'price': apts.css('div.list-card-price::text').get(),
                'link': apts.css('a.list-card-link.list-card-link-top-margin').attrib['href'],
            }

            # yield{
            #     'location': apts.css('address.list-card-addr::text').get(),
            #     'price': apts.css('div.list-card-price::text').get(),
            #     'link': apts.css('a.list-card-link.list-card-link-top-margin.list-card-img').attrib['href'],
            # }
